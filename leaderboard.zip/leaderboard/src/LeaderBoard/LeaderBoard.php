<?php

declare(strict_types=1);

namespace LeaderBoard;

use pocketmine\math\Vector3;
use pocketmine\plugin\{
    Plugin, PluginBase
};
use pocketmine\utils\Config;

use LeaderBoard\task\KillLeaderBoardTask;

class LeaderBoard extends PluginBase{
    public static $warnings = [
        KillLeaderBoardTask::class => false
	];
    
    /**
     * @return void
     */
    public function onEnable() : void{
        $this->saveDefaultConfig();
        $this->saveResource("leaderboards.yml");
	    
        if(!$this->getServer()->getPluginManager()->getPlugin("ProfileUI") instanceof Plugin){
            $this->getLogger()->critical("ProfileUI by Infernus101 is required for this plugin to work.");
            $this->setEnabled(false);
	     return;
        }
	    
        $this->getLogger()->info("Initializing leaderboards...");
        $this->initLeaderBoards();
    }
    
    /**
     * Initializes the leaderboards.
     *
     * @return void
     */
    private function initLeaderBoards() : void{
        $leaderBoards = (new Config($this->getDataFolder() . "leaderboards.yml", Config::YAML))->getAll(); 
        if(isset($leaderBoards["leaderboards"]) and is_array($leaderBoards["leaderboards"])){
            $lang = $this->getConfig()->get("language");
            $refreshRate = $this->getConfig()->get("refresh-rate");
            
	     ////////// Leaderboards //////////
            $killLeaderBoard = $leaderBoards["leaderboards"]["kill"];
            $this->getServer()->getScheduler()->scheduleRepeatingTask(new KillLeaderBoardTask($this, new Vector3($killLeaderBoard[0], $killLeaderBoard[1], $killLeaderBoard[2]), $killLeaderBoard[3], $lang), $refreshRate);
            ////////// LeaderBoards //////////
			
            $count = count($leaderBoards["leaderboards"]);
            $this->getLogger()->info("Loaded " . $count . " leaderboards");
        }else{
            $this->getLogger()->critical("leaderboards.yml is invalid, disabling plugin...");
            $this->setEnabled(false);
        }
    }
        
}